This is a really, REALLY simple script to open a bunch of tabs in Chrome and have them all start playing a YouTube video, featuring Eric Cartman.
It could be modified to use Firefox instead. 

Tested on Windows 10 and Windows 11. Possibly works on Windows 7 (God rest her soul). 
