# SUS - *SAFE*

It would be a spoiler if i did show you this.\
So, run it and see :)

For those that are scared, here is a description
<details>
  <summary>Description - SPOILER</summary>
  
  This is just a simple exe containing a twerking among us character. It places a window on the screen that has no cross and it's not in the task bar.\
  Simply, annoying as fuck.\
  You can close it from the task manager
  
</details>
