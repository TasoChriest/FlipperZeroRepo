
# StickyKeysSWAP

This script modifies the system file "sethc.exe" on a computer running Windows by adding full control access rules for "Everyone", replacing the file with the "cmd.exe" file, and setting the access control list of the file to the modified access control list.

## How to use?

This script is plug and play. Just plug in the Flipper and run the script.


## Features

- open powershell 
- replace cmd.exe



## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


