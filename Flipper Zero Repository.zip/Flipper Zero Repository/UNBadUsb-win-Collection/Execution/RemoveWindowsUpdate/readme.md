
# RemoveWindowsUpdate

This script uninstalls a Windows update that has been previously installed on the system.



## How to use?

This script is not plug and play. You will have to do the following changes:

- change update number "$input="UPDATE NUMBER""


## Features

- open powershell 
- find update by number
- uninstall update





## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


