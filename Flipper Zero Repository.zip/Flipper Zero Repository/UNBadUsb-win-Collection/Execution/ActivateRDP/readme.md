
# ActivateRDP

This script enables Remote Desktop connections and requires RDP authentication, so it opens the necessary firewall ports to allow incoming connections.




## How to use?

This script is easy to use. Plug the Flipper in and run the script. 




## Features

- allows remote connections
- enables RDP authentication
- allow incoming remote connections




## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


