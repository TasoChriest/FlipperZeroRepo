
# DownloadAnyEXE

This script downloads an exe from an url that you will have to provide, then it executes the exe file.



## How to use?

This script is not plug and play. You will have to do the following changes:

- change url for the .exe file "$url = "URL TO EXE""



## Features

- open powershell
- download .exe from url
- execute downloaded .exe





## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


