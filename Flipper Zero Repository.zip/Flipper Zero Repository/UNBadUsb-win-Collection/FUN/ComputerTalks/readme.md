
# ComputerTalks
Makes the computer speak.

## How to use?

This script is not plug and play. You need to do the following changes:

- change the text if you WANT to "$synth.Speak('Hello you behind the Screen, I am inside your PC.')""


## Features

- open powershell 
- use system.speech to talk


## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


