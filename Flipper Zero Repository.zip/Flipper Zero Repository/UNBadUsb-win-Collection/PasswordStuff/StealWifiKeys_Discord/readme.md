
# StealWifiKeys_Discord
Steals all of the saved Wifi Passwords, stores them to a file and uplaods the file to a discord webhook.

## How to use?

This script is not plug and play. You will need to do the following changes:

- change webhook url 


## Features

- open powershell
- grab wifi keys
- store keys to a file
- sends file to discord webhook

## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.
