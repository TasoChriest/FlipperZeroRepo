# rubber ducky windows password grabber
https://github.com/makozort/RDwindowspasswordgrabber
I am not responsible for any misuse of this script, you may only use it for PEN testing systems you own or have permission to do so to
a PEN testing script for the rubber ducky that grabs the users login passwords, they will need to be decrypted using NTML method

makes exception, downloads mimikatz, grabs user passwords, emails them to you via gmail, and cleans up after for you and targets safety :)

encode it here I guess: https://ducktoolkit.com/encode#

make sure you fill in the areas of the script that need to be, for example "PASSWORDHERE" and all the others


