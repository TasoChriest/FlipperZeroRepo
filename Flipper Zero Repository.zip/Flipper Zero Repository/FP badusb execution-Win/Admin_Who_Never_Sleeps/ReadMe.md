**Admin who never sleeps** (for Windows)

Quick and simple script that adds a local hidden admin user then sets power settings to never sleep.

**User**: WinSystem
<br>
**Pass**: Some-P@ssw0rd

You're able to easily replace the above info, but make sure it's done everywhere! The name is used to hide it from view.

_NOTE: Local admin required first!_
