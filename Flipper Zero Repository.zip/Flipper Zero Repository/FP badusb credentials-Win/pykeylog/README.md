# Inputs To Mail.
https://github.com/aydinnyunus/Keylogger

Get Keyboard,Mouse,ScreenShot,Microphone Inputs and Send to your Mail.
Purpose of the project is testing the security of information systems

## INSTALLATION

**You don't need to do anything for installation just run the script**

![github-small](/images/Adsız.png)

## USAGE

•**Set your own MAIL and PASSWORD on "keylogger.py".**

•**Run keylogger.py on Target Computer**

•**Every 10 seconds,You Get the Data from the Target Computer**

•**If Target finds the Code and Open the File for Want to Learn your MAIL and Password The Program DELETE itself.**

## USAGE TEMP MAIL API

#### https://temp-mail.org/en/api/


## ANTIVIRUS TEST

![github-small](/images/1.png)

![github-small](/images/2.png)

However, if you've made some money using my tools or just want to encourage me to continue creating stuff, please consider giving back on 
**BTC Wallet : 1NqDy1VdF5wkvxBcojbADWexPhPzza6LGF** my efforts and help it grow by buying me coffee - but only if you're definitely able to! 😊🎉

---

### Contact Me !

[<img target="_blank" src="https://img.icons8.com/bubbles/100/000000/linkedin.png" title="LinkedIn">](https://linkedin.com/in/yunus-ayd%C4%B1n-b9b01a18a/)       [<img target="_blank" src="https://img.icons8.com/bubbles/100/000000/github.png" title="Github">](https://github.com/aydinnyunus/WhatsappBOT)     [<img target="_blank" src="https://img.icons8.com/bubbles/100/000000/instagram-new.png" title="Instagram">](https://instagram.com/aydinyunus_/) [<img target="_blank" src="https://img.icons8.com/bubbles/100/000000/twitter.png" title="LinkedIn">](https://twitter.com/aydinnyunuss)


## Another Projects : 

•**WHATSAPP BOT** : https://github.com/aydinnyunus/WhatsappBOT

•**MACHINE LEARNING** : https://github.com/aydinnyunus/Machine-Learning

•**FACE RECOGNITION SECURITY** : https://github.com/aydinnyunus/FaceRecognitionSecurity

